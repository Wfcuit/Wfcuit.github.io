# My520
520表白神器
@[TOC](目录)

## 一：项目展示
项目效果：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200625202043188.gif)
在线演示：
[https://xuyuanzhi051.github.io/My520/](https://xuyuanzhi051.github.io/My520/)


## 二：使用方法
使用方法：下载代码包，自行替换文本和图片即可。
项目源码：[https://github.com/xuyuanzhi051/My520](https://github.com/xuyuanzhi051/My520)
**定制：**
**1. 主页 index.html**
无需修改任何内容

**2. 展示页 show.html**
111行修改日期
135行修改表白者/被表白者姓名
**3. 结果页 result.html**
- 替换内容：在编辑器中按ctrl+f全局搜索"{{替换"，对内容进行替换
- 替换图片：覆盖images目录下的文件（除baidu.png）
- 替换音乐：覆盖bgMusic.mp3文件
## 三：项目部署
这是一个静态网站，可以在任何一个平台上部署，例如github,gitee,也可以部署到自己的服务器上。
**例：在github上部署**
1. 新建一个仓库
2. 把代码放到你的仓库中去
3. 在仓库setting里面更改githubPages中的source为master branch
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200625203108601.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQ0ODY3MzQw,size_16,color_FFFFFF,t_70)
项目的主页默认是index.html，项目后面就不用加上文件名了
如果是别的名字，项目后面需要加上别的名字。
